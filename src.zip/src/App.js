<Route path="/client/home" element={<ClientHome />} />
<Route path="/client/book" element={<BookAppointment />} />
<Route path="/client/request" element={<RequestLocation />} />
<Route path="/client/history" element={<CarHistory />} />
<Route path="/client/about" element={<AboutClient />} />
