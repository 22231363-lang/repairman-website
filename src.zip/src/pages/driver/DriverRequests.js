import React, { useEffect, useState } from "react";
import AOS from "aos";
import DriverNavbar from "../../components/DriverNavbar";
import "aos/dist/aos.css";

const demoRequests = [
  {
    id: 1,
    client: "Ali Hassan",
    phone: "03-123456",
    car: "Toyota Corolla 2021",
    plate: "123-ABC",
    problem: "Car won't start",
    location: "Hamra, Beirut",
    requestTime: "2025-12-15 09:45 AM",
    status: "Pending",
  },
  {
    id: 2,
    client: "Sara Ahmad",
    phone: "71-987654",
    car: "Honda Civic 2020",
    plate: "456-DEF",
    problem: "Flat tire",
    location: "Jounieh",
    requestTime: "2025-12-15 10:10 AM",
    status: "Pending",
  },
];

function DriverRequests() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
    setRequests(demoRequests);
  }, []);

  const updateStatus = (id, status) => {
    setRequests(
      requests.map(req =>
        req.id === id ? { ...req, status } : req
      )
    );
  };

  return (
    <>
      <DriverNavbar />

      <div className="container mt-5">
        <h2 className="text-center fw-bold mb-4" data-aos="fade-down">
          Location Help Requests
        </h2>

        <div className="row g-4">
          {requests.map((req, index) => (
            <div
              className="col-md-6"
              key={req.id}
              data-aos="fade-up"
              data-aos-delay={index * 150}
            >
              <div className="card shadow-sm border-0 h-100">
                <div className="card-body">
                  <h5 className="fw-bold">{req.client}</h5>

                  <p className="mb-1"><strong>Phone:</strong> {req.phone}</p>
                  <p className="mb-1"><strong>Car:</strong> {req.car}</p>
                  <p className="mb-1"><strong>Plate:</strong> {req.plate}</p>
                  <p className="mb-1"><strong>Problem:</strong> {req.problem}</p>
                  <p className="mb-1"><strong>Location:</strong> {req.location}</p>
                  <p className="mb-2">
                    <strong>Requested At:</strong> {req.requestTime}
                  </p>

                  <span className={`badge mb-3 ${
                    req.status === "Pending" ? "bg-warning" :
                    req.status === "On The Way" ? "bg-primary" :
                    req.status === "Completed" ? "bg-success" :
                    "bg-danger"
                  }`}>
                    {req.status}
                  </span>

                  {/* ACTIONS */}
                  {req.status === "Pending" && (
                    <div className="d-flex gap-2">
                      <button
                        className="btn btn-success btn-sm"
                        onClick={() => updateStatus(req.id, "On The Way")}
                      >
                        Accept
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => updateStatus(req.id, "Rejected")}
                      >
                        Reject
                      </button>
                    </div>
                  )}

                  {req.status === "On The Way" && (
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={() => updateStatus(req.id, "Completed")}
                    >
                      Mark as Completed
                    </button>
                  )}

                  {req.status === "Completed" && (
                    <div className="alert alert-success p-2 mt-2">
                      Job completed successfully.
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default DriverRequests;
