import React, { useEffect, useState } from "react";
import AOS from "aos";
import DriverNavbar from "../../components/DriverNavbar";
import "aos/dist/aos.css";

const demoRequests = [
  {
    id: 1,
    client: "Ali Hassan",
    problem: "Car won’t start",
    location: "Hamra, Beirut",
    status: "Pending",
  },
  {
    id: 2,
    client: "Sara Ahmad",
    problem: "Flat tire",
    location: "Jounieh",
    status: "Pending",
  },
];

function DriverDashboard() {
  const [online, setOnline] = useState(false);
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
    setRequests(demoRequests);
  }, []);

  const acceptRequest = (id) => {
    setRequests(
      requests.map(r =>
        r.id === id ? { ...r, status: "On The Way" } : r
      )
    );
  };

  const rejectRequest = (id) => {
    setRequests(requests.filter(r => r.id !== id));
  };

  return (
    <>
      <DriverNavbar />

      <div className="container mt-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2 className="fw-bold" data-aos="fade-right">Driver Dashboard</h2>

          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              checked={online}
              onChange={() => setOnline(!online)}
            />
            <label className="form-check-label fw-bold">
              {online ? "Online" : "Offline"}
            </label>
          </div>
        </div>

        {!online && (
          <div className="alert alert-warning">
            You are offline. Clients cannot see you.
          </div>
        )}

        {online && (
          <div className="row g-4">
            {requests.map((req, index) => (
              <div
                className="col-md-6"
                key={req.id}
                data-aos="fade-up"
                data-aos-delay={index * 150}
              >
                <div className="card shadow-sm border-0 p-3">
                  <h5 className="fw-bold">{req.client}</h5>
                  <p><strong>Problem:</strong> {req.problem}</p>
                  <p><strong>Location:</strong> {req.location}</p>

                  <span className={`badge mb-2 ${
                    req.status === "Pending" ? "bg-warning" : "bg-success"
                  }`}>
                    {req.status}
                  </span>

                  {req.status === "Pending" && (
                    <div className="d-flex gap-2">
                      <button
                        className="btn btn-success btn-sm"
                        onClick={() => acceptRequest(req.id)}
                      >
                        Accept
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => rejectRequest(req.id)}
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

export default DriverDashboard;
