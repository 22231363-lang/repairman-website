import React, { useEffect } from "react";
import AOS from "aos";
import 'aos/dist/aos.css';
import ClientNavbar from "../components/ClientNavbar";

function About() {
  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  return (
    <>
      <ClientNavbar />

      {/* HERO SECTION */}
      <div
        className="bg-primary text-white text-center py-5"
        data-aos="fade-down"
      >
        <h1 className="fw-bold">About Us</h1>
        <p className="lead mt-3">
          Welcome to our Car Repair Service! We have been serving customers since 2020 with professionalism and care.
        </p>
      </div>

      <div className="container my-5">
        {/* OUR STORY */}
        <section className="mb-5" data-aos="fade-right">
          <h2 className="fw-bold mb-3">Our Story</h2>
          <p>
            We started our journey in 2020 with the mission to provide reliable and fast car repair services.
            Our team of professional repairmen ensures that every car is treated with care and precision. Over the years, we have expanded our services to include on-location repair and client consultations.
          </p>
        </section>

        {/* MISSION & VISION */}
        <section className="row g-4 mb-5">
          <div className="col-md-6" data-aos="fade-up">
            <div className="card shadow-sm border-0 h-100 p-3">
              <h4 className="fw-bold">Our Mission</h4>
              <p>
                To provide high-quality car repair services with honesty, reliability, and efficiency. We aim to ensure every client leaves satisfied.
              </p>
            </div>
          </div>
          <div className="col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div className="card shadow-sm border-0 h-100 p-3">
              <h4 className="fw-bold">Our Vision</h4>
              <p>
                To become the most trusted car repair service in the region, known for excellent service and innovative solutions, including on-location repairs.
              </p>
            </div>
          </div>
        </section>

        {/* TEAM / IMAGE CARDS */}
        <section className="mb-5">
          <h2 className="fw-bold mb-4 text-center" data-aos="fade-down">
            Meet Our Team
          </h2>
          <div className="row g-4">
            <div className="col-md-4" data-aos="zoom-in">
              <div className="card shadow-sm border-0">
                <img
                  src="https://via.placeholder.com/300x200"
                  className="card-img-top"
                  alt="Team member"
                />
                <div className="card-body text-center">
                  <h5 className="card-title">Ahmad Khalil</h5>
                  <p className="card-text">Senior Repairman</p>
                </div>
              </div>
            </div>
            <div className="col-md-4" data-aos="zoom-in" data-aos-delay="150">
              <div className="card shadow-sm border-0">
                <img
                  src="https://via.placeholder.com/300x200"
                  className="card-img-top"
                  alt="Team member"
                />
                <div className="card-body text-center">
                  <h5 className="card-title">Hassan Saleh</h5>
                  <p className="card-text">Engine Specialist</p>
                </div>
              </div>
            </div>
            <div className="col-md-4" data-aos="zoom-in" data-aos-delay="300">
              <div className="card shadow-sm border-0">
                <img
                  src="https://via.placeholder.com/300x200"
                  className="card-img-top"
                  alt="Team member"
                />
                <div className="card-body text-center">
                  <h5 className="card-title">Mohammad Ali</h5>
                  <p className="card-text">Electrical Systems</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default About;
