import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../styles/Login.css";

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  const handleLogin = (e) => {
    e.preventDefault();

    // 🔹 Example validation (replace with real backend API)
    if (email === "" || password === "") {
      setError("Please fill all fields.");
      return;
    }

    // 🔹 Dummy login logic (replace with real login check)
    if (email === "client@example.com" && password === "123456") {
      navigate("/client/search"); // redirect client dashboard
    } else if (email === "workshop@example.com" && password === "123456") {
      navigate("/workshop/dashboard"); // redirect workshop
    } else if (email === "driver@example.com" && password === "123456") {
      navigate("/driver/dashboard"); // redirect driver
    } else if (email === "admin@example.com" && password === "123456") {
      navigate("/admin/dashboard"); // redirect admin
    } else {
      setError("Invalid email or password.");
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleLogin} data-aos="fade-up">
        <h2 className="text-center mb-4">Login</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input 
            type="email" 
            className="form-control" 
            id="email" 
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input 
            type="password" 
            className="form-control" 
            id="password" 
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn btn-primary mb-3">Login</button>

        <p className="text-center">
          Don't have an account? <Link to="/register">Register here</Link>
        </p>
      </form>
    </div>
  );
}

export default Login;
