import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../styles/Register.css";

function Register() {
  const navigate = useNavigate();

  const [role, setRole] = useState(""); // Client, Workshop, Driver
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    phone: "",
    city: "",
    address: "",
    skills: "",
    experience: "",
    cv: null,
    workshopPhoto: null,
    carPhoto: null,
    plateNumber: "",
  });
  const [error, setError] = useState("");

  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Basic validation
    if (!formData.fullName || !formData.email || !formData.password || !formData.phone || !formData.city) {
      setError("Please fill all required fields.");
      return;
    }

    if (role === "") {
      setError("Please select a role.");
      return;
    }

    // For repairman, check extra fields
    if ((role === "Workshop" || role === "Driver") && !formData.cv) {
      setError("Please upload your CV.");
      return;
    }

    if (role === "Workshop" && !formData.workshopPhoto) {
      setError("Please upload workshop photo.");
      return;
    }

    if (role === "Driver" && (!formData.carPhoto || !formData.plateNumber)) {
      setError("Please upload car photo and enter plate number.");
      return;
    }

    // 🔹 Dummy registration logic
    alert(`Registration successful for ${role}! Waiting for admin approval if repairman.`);

    // Redirect to login after registration
    navigate("/login");
  };

  return (
    <div className="register-container">
      <form className="register-form" onSubmit={handleSubmit} data-aos="fade-up">
        <h2 className="text-center mb-4">Register</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        {/* Basic Info */}
        <div className="mb-3">
          <label className="form-label">Full Name</label>
          <input type="text" className="form-control" name="fullName" value={formData.fullName} onChange={handleChange} />
        </div>

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input type="email" className="form-control" name="email" value={formData.email} onChange={handleChange} />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input type="password" className="form-control" name="password" value={formData.password} onChange={handleChange} />
        </div>

        <div className="mb-3">
          <label className="form-label">Phone</label>
          <input type="text" className="form-control" name="phone" value={formData.phone} onChange={handleChange} />
        </div>

        <div className="mb-3">
          <label className="form-label">City</label>
          <input type="text" className="form-control" name="city" value={formData.city} onChange={handleChange} />
        </div>

        <div className="mb-3">
          <label className="form-label">Address</label>
          <input type="text" className="form-control" name="address" value={formData.address} onChange={handleChange} />
        </div>

        {/* Role Selection */}
        <div className="mb-3">
          <label className="form-label">I am a:</label>
          <select className="form-select" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="">Select Role</option>
            <option value="Client">Client</option>
            <option value="Workshop">Repairman – Workshop</option>
            <option value="Driver">Repairman – Driver</option>
          </select>
        </div>

        {/* Conditional Fields for Repairman */}
        {(role === "Workshop" || role === "Driver") && (
          <>
            <div className="mb-3">
              <label className="form-label">Skills</label>
              <textarea className="form-control" name="skills" value={formData.skills} onChange={handleChange} placeholder="e.g. Engine, Electrical, Tires"></textarea>
            </div>

            <div className="mb-3">
              <label className="form-label">Years of Experience</label>
              <input type="number" className="form-control" name="experience" value={formData.experience} onChange={handleChange} />
            </div>

            <div className="mb-3">
              <label className="form-label">Upload CV</label>
              <input type="file" className="form-control" name="cv" onChange={handleChange} />
            </div>
          </>
        )}

        {/* Workshop Specific */}
        {role === "Workshop" && (
          <div className="mb-3">
            <label className="form-label">Workshop Photo</label>
            <input type="file" className="form-control" name="workshopPhoto" onChange={handleChange} />
          </div>
        )}

        {/* Driver Specific */}
        {role === "Driver" && (
          <>
            <div className="mb-3">
              <label className="form-label">Car Photo</label>
              <input type="file" className="form-control" name="carPhoto" onChange={handleChange} />
            </div>

            <div className="mb-3">
              <label className="form-label">Plate Number</label>
              <input type="text" className="form-control" name="plateNumber" value={formData.plateNumber} onChange={handleChange} />
            </div>
          </>
        )}

        <button type="submit" className="btn btn-primary mb-3">Register</button>

        <p className="text-center">
          Already have an account? <Link to="/login">Login here</Link>
        </p>
      </form>
    </div>
  );
}

export default Register;
