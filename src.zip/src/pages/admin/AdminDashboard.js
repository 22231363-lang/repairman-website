import React, { useEffect, useState } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../styles/AdminDashboard.css";

function AdminDashboard() {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  // Dummy data for pending repairmen (replace with backend data)
  const [pendingRepairmen, setPendingRepairmen] = useState([
    { id: 1, name: "John Doe", role: "Workshop", email: "john@example.com", skills: "Engine, Electrical" },
    { id: 2, name: "Jane Smith", role: "Driver", email: "jane@example.com", skills: "Towing, Tires" },
  ]);

  const handleApprove = (id) => {
    alert(`Repairman with ID ${id} approved!`);
    setPendingRepairmen(pendingRepairmen.filter(user => user.id !== id));
  };

  const handleReject = (id) => {
    alert(`Repairman with ID ${id} rejected!`);
    setPendingRepairmen(pendingRepairmen.filter(user => user.id !== id));
  };

  return (
    <div className="container my-5">
      <h2 className="text-center mb-5" data-aos="fade-up">Admin Dashboard - Pending Repairmen</h2>

      {pendingRepairmen.length === 0 ? (
        <p className="text-center" data-aos="fade-up">No pending repairmen at the moment.</p>
      ) : (
        <div className="row" data-aos="fade-up">
          {pendingRepairmen.map(user => (
            <div className="col-md-6 mb-4" key={user.id}>
              <div className="card shadow-sm p-3 h-100">
                <h5 className="card-title">{user.name} <span className="badge bg-primary">{user.role}</span></h5>
                <p className="card-text"><strong>Email:</strong> {user.email}</p>
                <p className="card-text"><strong>Skills:</strong> {user.skills}</p>
                <div className="d-flex justify-content-end">
                  <button className="btn btn-success me-2" onClick={() => handleApprove(user.id)}>Approve</button>
                  <button className="btn btn-danger" onClick={() => handleReject(user.id)}>Reject</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;
