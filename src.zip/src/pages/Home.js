import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/Home.css";

function Home() {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  return (
    <div>
      {/* HERO SECTION */}
      <section
        className="hero-section text-center text-white d-flex align-items-center justify-content-center"
        style={{
          height: "100vh",
          backgroundImage: "url('https://images.unsplash.com/photo-1601380301210-cf735e3bce1c?auto=format&fit=crop&w=1470&q=80')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="container" data-aos="fade-up">
          <h1 className="display-3 fw-bold mb-3">Welcome to RepairConnect</h1>
          <p className="lead mb-4">Fast, reliable, and professional car repair assistance anytime, anywhere!</p>
          <Link to="/register" className="btn btn-primary btn-lg me-2" data-aos="zoom-in" data-aos-delay="200">
            Get Started
          </Link>
          <Link to="/login" className="btn btn-outline-light btn-lg" data-aos="zoom-in" data-aos-delay="400">
            Login
          </Link>
        </div>
      </section>

      {/* MISSION & VALUES SECTION */}
      <section className="py-5 bg-light">
        <div className="container">
          <h2 className="text-center mb-5" data-aos="fade-up">Our Mission & Values</h2>
          <div className="row text-center">

            <div className="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
              <div className="card border-0 shadow-sm p-4 h-100">
                <i className="bi bi-speedometer2 display-4 text-primary mb-3"></i>
                <h5 className="fw-bold">Fast Service</h5>
                <p>We deliver repair services quickly, so you’re never stuck on the road for long.</p>
              </div>
            </div>

            <div className="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
              <div className="card border-0 shadow-sm p-4 h-100">
                <i className="bi bi-shield-check display-4 text-primary mb-3"></i>
                <h5 className="fw-bold">Trusted Professionals</h5>
                <p>All our repairmen are verified and approved by the admin to ensure quality service.</p>
              </div>
            </div>

            <div className="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
              <div className="card border-0 shadow-sm p-4 h-100">
                <i className="bi bi-geo-alt display-4 text-primary mb-3"></i>
                <h5 className="fw-bold">Anywhere, Anytime</h5>
                <p>Whether at home or on the road, our drivers and workshops come to you when needed.</p>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;
