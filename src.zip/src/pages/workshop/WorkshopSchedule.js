import React, { useEffect, useState } from "react";
import AOS from "aos";
import WorkshopNavbar from "../../components/WorkshopNavbar";
import "aos/dist/aos.css";

const appointmentsData = [
  {
    id: 1,
    client: "Ali Hassan",
    car: "123-ABC",
    carModel: "Toyota Corolla 2021",
    date: "2025-12-15",
    time: "10:00 AM",
    status: "Pending",
  },
  {
    id: 2,
    client: "Hassan Saleh",
    car: "456-DEF",
    carModel: "Honda Civic 2020",
    date: "2025-12-16",
    time: "2:00 PM",
    status: "Confirmed",
  },
];

function WorkshopSchedule() {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
    setAppointments(appointmentsData);
  }, []);

  const updateStatus = (id, status) => {
    setAppointments(
      appointments.map(a =>
        a.id === id ? { ...a, status } : a
      )
    );
  };

  return (
    <>
      <WorkshopNavbar />

      <div className="container mt-5">
        <h2 className="text-center fw-bold mb-4" data-aos="fade-down">
          Workshop Schedule
        </h2>

        <div className="row g-4">
          {appointments.map((appt, index) => (
            <div
              className="col-md-6"
              key={appt.id}
              data-aos="fade-up"
              data-aos-delay={index * 150}
            >
              <div className="card shadow-sm border-0 p-3">
                <h5 className="fw-bold">{appt.client}</h5>
                <p className="mb-1"><strong>Car:</strong> {appt.carModel}</p>
                <p className="mb-1"><strong>Plate:</strong> {appt.car}</p>
                <p className="mb-1"><strong>Date:</strong> {appt.date}</p>
                <p className="mb-1"><strong>Time:</strong> {appt.time}</p>

                <span className={`badge mb-2 ${
                  appt.status === "Pending" ? "bg-warning" :
                  appt.status === "Confirmed" ? "bg-primary" :
                  "bg-success"
                }`}>
                  {appt.status}
                </span>

                <div className="d-flex gap-2 mt-2">
                  {appt.status === "Pending" && (
                    <button
                      className="btn btn-sm btn-primary"
                      onClick={() => updateStatus(appt.id, "Confirmed")}
                    >
                      Confirm
                    </button>
                  )}

                  {appt.status !== "Completed" && (
                    <button
                      className="btn btn-sm btn-success"
                      onClick={() => updateStatus(appt.id, "Completed")}
                    >
                      Complete
                    </button>
                  )}

                  {appt.status === "Completed" && (
                    <a
                      href={`/workshop-reports?car=${appt.car}&client=${appt.client}`}
                      className="btn btn-sm btn-outline-secondary"
                    >
                      Add Report
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default WorkshopSchedule;
