import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import WorkshopNavbar from "../../components/WorkshopNavbar";
import { saveReport } from "../../utils";

function Reports() {
  const location = useLocation();
  const params = new URLSearchParams(location.search);

  const [carId] = useState(params.get("car") || "");
  const [client] = useState(params.get("client") || "");
  const [problem, setProblem] = useState("");
  const [service, setService] = useState("");

  const submitReport = () => {
    if (!problem || !service) {
      alert("Please fill all fields");
      return;
    }

    const report = {
      date: new Date().toISOString().split("T")[0],
      repairman: "Workshop Repairman",
      problem,
      service,
    };

    saveReport(carId, report);
    alert("Report saved successfully");
    setProblem("");
    setService("");
  };

  return (
    <>
      <WorkshopNavbar />

      <div className="container mt-5">
        <h2 className="text-center fw-bold mb-4">Car Repair Report</h2>

        <div className="card shadow-sm p-4">
          <div className="mb-3">
            <label className="form-label">Client</label>
            <input className="form-control" value={client} disabled />
          </div>

          <div className="mb-3">
            <label className="form-label">Car Plate</label>
            <input className="form-control" value={carId} disabled />
          </div>

          <div className="mb-3">
            <label className="form-label">Problem</label>
            <textarea
              className="form-control"
              value={problem}
              onChange={e => setProblem(e.target.value)}
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Service Done</label>
            <textarea
              className="form-control"
              value={service}
              onChange={e => setService(e.target.value)}
            />
          </div>

          <button className="btn btn-primary" onClick={submitReport}>
            Save Report
          </button>
        </div>
      </div>
    </>
  );
}

export default Reports;
