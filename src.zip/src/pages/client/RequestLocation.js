import React, { useEffect, useState } from "react";
import AOS from "aos";
import ClientNavbar from "../../components/ClientNavbar";

/* REGISTERED DRIVER-REPAIRMEN */
const repairmen = [
  { id: 1, name: "Ali Hassan", location: "Beirut", distance: "2.1 km", status: "online" },
  { id: 2, name: "Mohammad Saleh", location: "Hamra", distance: "3.5 km", status: "offline" },
  { id: 3, name: "Hussein Ahmad", location: "Achrafieh", distance: "5 km", status: "online" },
];

function RequestLocation() {
  const [selectedRepairman, setSelectedRepairman] = useState(null);
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);
  const [requestConfirmed, setRequestConfirmed] = useState(false);
  const [rating, setRating] = useState(0);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  /* SEND MESSAGE LOGIC */
  const sendMessage = () => {
    if (!message) return;

    const newChat = [
      ...chat,
      { sender: "client", text: message },
      {
        sender: "repairman",
        text: "I can help you. Price is $50 and arrival in 30 minutes.",
      },
    ];

    setChat(newChat);
    setMessage("");
  };

  /* CONFIRM REQUEST */
  const confirmRequest = () => {
    if (chat.length === 0) {
      alert("⚠️ Please chat with the repairman before confirming.");
      return;
    }

    setRequestConfirmed(true);
    alert("✅ Request confirmed successfully!");
  };

  /* SUBMIT RATING */
  const submitRating = () => {
    if (rating === 0) {
      alert("⚠️ Please select a rating before submitting.");
      return;
    }
    alert(`⭐ Thank you! You rated ${rating} star(s).`);
    // Reset page (optional)
    setSelectedRepairman(null);
    setChat([]);
    setMessage("");
    setRating(0);
    setRequestConfirmed(false);
  };

  return (
    <>
      <ClientNavbar />

      <div className="container mt-5">
        <h2 className="text-center fw-bold mb-4" data-aos="fade-down">
          Request Repairman On Location
        </h2>

        <div className="row g-4">
          {/* MAP & REPAIRMEN LIST */}
          <div className="col-md-6" data-aos="fade-right">
            <div className="p-3 border rounded shadow-sm mb-4">
              <h5 className="fw-bold mb-3">Nearby Repairmen (Map)</h5>

              {/* MAP SIMULATION WITH ANIMATED PINS */}
              <div
                className="bg-light position-relative d-flex align-items-center justify-content-center"
                style={{ height: "250px", borderRadius: "10px" }}
              >
                {repairmen.map((r, index) => (
                  <div
                    key={r.id}
                    className="position-absolute"
                    style={{
                      top: `${50 + index * 30}px`,
                      left: `${20 + index * 30}%`,
                    }}
                    data-aos="zoom-in"
                    data-aos-delay={index * 200}
                  >
                    <span
                      className="d-inline-block rounded-circle"
                      style={{
                        width: "20px",
                        height: "20px",
                        backgroundColor: r.status === "online" ? "green" : "red",
                        boxShadow: "0 0 6px rgba(0,0,0,0.3)",
                      }}
                    ></span>
                    <small className="d-block text-center">{r.name}</small>
                  </div>
                ))}

                <span className="text-muted position-absolute top-50 start-50 translate-middle">
                  📍 Map showing repairmen locations
                </span>
              </div>

              {/* REPAIRMEN LIST */}
              <ul className="list-group mt-3">
                {repairmen.map((r) => (
                  <li
                    key={r.id}
                    className={`list-group-item d-flex justify-content-between align-items-center ${
                      selectedRepairman?.id === r.id ? "active" : ""
                    }`}
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      setSelectedRepairman(r);
                      setChat([]);
                      setRequestConfirmed(false);
                      setRating(0);
                    }}
                  >
                    <div>
                      <strong>
                        {r.name}{" "}
                        <span
                          className="ms-2 d-inline-block rounded-circle"
                          style={{
                            width: "12px",
                            height: "12px",
                            backgroundColor: r.status === "online" ? "green" : "red",
                          }}
                        ></span>
                      </strong>
                      <br />
                      <small>{r.location}</small>
                    </div>
                    <span className="badge bg-primary rounded-pill">{r.distance}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* CHAT BOARD */}
          <div className="col-md-6" data-aos="fade-left">
            <div className="card shadow h-100">
              <div className="card-header fw-bold">
                {selectedRepairman
                  ? `Chat with ${selectedRepairman.name}`
                  : "Select a repairman to start chat"}
              </div>

              <div
                className="card-body"
                style={{ height: "300px", overflowY: "auto" }}
              >
                {chat.length === 0 && <p className="text-muted">No messages yet.</p>}

                {chat.map((c, index) => (
                  <div
                    key={index}
                    className={`mb-2 ${c.sender === "client" ? "text-end" : "text-start"}`}
                  >
                    <span
                      className={`badge ${
                        c.sender === "client" ? "bg-success" : "bg-secondary"
                      }`}
                    >
                      {c.text}
                    </span>
                  </div>
                ))}
              </div>

              {selectedRepairman && !requestConfirmed && (
                <div className="card-footer d-flex flex-column">
                  <div className="d-flex mb-2">
                    <input
                      type="text"
                      className="form-control me-2"
                      placeholder="Describe your problem..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                    />
                    <button className="btn btn-primary" onClick={sendMessage}>
                      Send
                    </button>
                  </div>
                  <button className="btn btn-success" onClick={confirmRequest}>
                    Confirm Request
                  </button>
                </div>
              )}

              {/* RATING AFTER REQUEST */}
              {requestConfirmed && (
                <div className="card-footer text-center">
                  <h6 className="fw-bold mb-2">Rate the Service:</h6>
                  <div className="mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span
                        key={star}
                        style={{
                          fontSize: "1.5rem",
                          cursor: "pointer",
                          color: star <= rating ? "#ffc107" : "#e4e5e9",
                        }}
                        onClick={() => setRating(star)}
                      >
                        ★
                      </span>
                    ))}
                  </div>
                  <button className="btn btn-primary" onClick={submitRating}>
                    Submit Rating
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default RequestLocation;
