import React, { useEffect, useState } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import "../../styles/BookWorkshop.css";

function BookWorkshop() {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  // Dummy workshops data
  const [workshops] = useState([
    { id: 1, name: "John's Workshop", skills: "Engine, Tires", city: "Beirut", email: "john@workshop.com" },
    { id: 2, name: "AutoFix Center", skills: "Electrical, Transmission", city: "Tripoli", email: "info@autofix.com" },
    { id: 3, name: "Speedy Repairs", skills: "Brakes, Suspension", city: "Saida", email: "contact@speedy.com" },
  ]);

  const handleBook = (id) => {
    const workshop = workshops.find((w) => w.id === id);
    alert(`You booked an appointment with ${workshop.name}!`);
    // Here you can connect to backend API to save the booking
  };

  return (
    <div className="container my-5">
      <h2 className="mb-4 text-center">Book a Workshop</h2>
      <div className="row">
        {workshops.map((w) => (
          <div className="col-md-6 mb-4" key={w.id} data-aos="fade-up">
            <div className="card p-3 shadow-sm h-100">
              <h5 className="card-title">{w.name}</h5>
              <p className="card-text"><strong>Skills:</strong> {w.skills}</p>
              <p className="card-text"><strong>City:</strong> {w.city}</p>
              <p className="card-text"><strong>Email:</strong> {w.email}</p>
              <button className="btn btn-primary" onClick={() => handleBook(w.id)}>
                Book Appointment
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default BookWorkshop;
