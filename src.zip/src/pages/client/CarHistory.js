import React, { useEffect, useState } from "react";
import AOS from "aos";
import ClientNavbar from "../../components/ClientNavbar";
import { getReports } from "../../utils";

const cars = [
  { id: "123-ABC", model: "Toyota Corolla", year: 2021 },
  { id: "456-DEF", model: "Honda Civic", year: 2020 },
];

function CarHistory() {
  const [openCar, setOpenCar] = useState(null);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  return (
    <>
      <ClientNavbar />

      <div className="container mt-5">
        <h2 className="text-center fw-bold mb-4" data-aos="fade-down">
          Car History
        </h2>

        <div className="row g-4">
          {cars.map((car, index) => (
            <div className="col-md-6" key={car.id} data-aos="fade-up" data-aos-delay={index * 150}>
              <div className="card shadow border-0">
                <div className="card-body">
                  <h5 className="fw-bold">{car.model} ({car.year})</h5>
                  <p><strong>Plate:</strong> {car.id}</p>

                  <button
                    className="btn btn-outline-primary"
                    onClick={() => setOpenCar(openCar === car.id ? null : car.id)}
                  >
                    {openCar === car.id ? "Hide Reports" : "View Reports"}
                  </button>

                  {openCar === car.id && (
                    <div className="mt-3">
                      {getReports(car.id).length === 0 && <p>No reports yet.</p>}

                      {getReports(car.id).map((r, i) => (
                        <div key={i} className="border rounded p-3 mb-2 shadow-sm">
                          <p><strong>Date:</strong> {r.date}</p>
                          <p><strong>Repairman:</strong> {r.repairman}</p>
                          <p><strong>Problem:</strong> {r.problem}</p>
                          <p><strong>Service:</strong> {r.service}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default CarHistory;
