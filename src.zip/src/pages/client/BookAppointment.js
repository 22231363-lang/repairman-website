import React, { useEffect, useState } from "react";
import AOS from "aos";
import ClientNavbar from "../../components/ClientNavbar";

/* ===============================
   DUMMY WORKSHOPS (Registered)
================================ */
const workshops = [
  {
    id: 1,
    workshop: "AutoFix Garage",
    repairman: "Ahmad Khalil",
    location: "Beirut",
    specialty: "Engine & Diagnostics",
  },
  {
    id: 2,
    workshop: "Speed Car Service",
    repairman: "Mohammad Ali",
    location: "Tripoli",
    specialty: "Brakes & Suspension",
  },
  {
    id: 3,
    workshop: "ProMechanic",
    repairman: "Hassan Saleh",
    location: "Sidon",
    specialty: "Electrical Systems",
  },
];

/* ===============================
   SIMULATED BOOKED APPOINTMENTS
================================ */
const bookedAppointments = [
  {
    workshopId: 1,
    date: "2025-06-20",
    time: "10:00",
  },
  {
    workshopId: 2,
    date: "2025-06-20",
    time: "14:00",
  },
];

function BookAppointment() {
  const [selectedWorkshop, setSelectedWorkshop] = useState(null);
  const [problem, setProblem] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  /* ===============================
     CHECK TIME CONFLICT
  ================================ */
  const checkConflict = () => {
    const conflict = bookedAppointments.find(
      (b) =>
        b.workshopId === selectedWorkshop.id &&
        b.date === date &&
        b.time === time
    );

    if (conflict) {
      setError(
        "❌ This time is already booked for this workshop. Please choose another time."
      );
      return false;
    }

    setError("");
    return true;
  };

  /* ===============================
     CONFIRM BOOKING
  ================================ */
  const handleBooking = () => {
    if (!problem || !date || !time) {
      setError("⚠️ Please fill in all fields.");
      return;
    }

    if (!checkConflict()) return;

    alert("✅ Booking confirmed successfully!");

    // Reset form
    setProblem("");
    setDate("");
    setTime("");
  };

  return (
    <>
      <ClientNavbar />

      <div className="container mt-5">
        <h2 className="text-center fw-bold mb-4" data-aos="fade-down">
          Book Workshop Appointment
        </h2>

        <div className="row g-4">
          {workshops.map((w, index) => (
            <div
              className="col-md-4"
              key={w.id}
              data-aos="fade-up"
              data-aos-delay={index * 150}
            >
              <div className="card shadow h-100 border-0">
                <div className="card-body text-center">
                  <h4 className="fw-bold">{w.workshop}</h4>
                  <p className="mb-1">
                    <strong>Repairman:</strong> {w.repairman}
                  </p>
                  <p className="mb-1">
                    <strong>Location:</strong> {w.location}
                  </p>
                  <p className="text-muted">
                    <strong>Specialty:</strong> {w.specialty}
                  </p>

                  <button
                    className="btn btn-primary mt-3"
                    data-bs-toggle="modal"
                    data-bs-target="#bookingModal"
                    onClick={() => {
                      setSelectedWorkshop(w);
                      setError("");
                    }}
                  >
                    Book Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ===============================
         BOOKING MODAL
      ================================ */}
      <div
        className="modal fade"
        id="bookingModal"
        tabIndex="-1"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">

            <div className="modal-header">
              <h5 className="modal-title">
                Book Appointment – {selectedWorkshop?.workshop}
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
              ></button>
            </div>

            <div className="modal-body">
              <div className="mb-3">
                <label className="form-label">Problem Description</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={problem}
                  onChange={(e) => setProblem(e.target.value)}
                  required
                ></textarea>
              </div>

              <div className="mb-3">
                <label className="form-label">Preferred Date</label>
                <input
                  type="date"
                  className="form-control"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Preferred Time</label>
                <input
                  type="time"
                  className="form-control"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required
                />
              </div>

              {error && (
                <div className="alert alert-danger mt-2">
                  {error}
                </div>
              )}
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-success"
                onClick={handleBooking}
              >
                Confirm Booking
              </button>
            </div>

          </div>
        </div>
      </div>
    </>
  );
}

export default BookAppointment;
