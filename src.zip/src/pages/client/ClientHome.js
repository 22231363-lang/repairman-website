import React, { useEffect } from "react";
import AOS from "aos";
import ClientNavbar from "../../components/ClientNavbar";

function ClientHome() {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      easing: "ease-in-out",
      once: true,
    });
  }, []);

  return (
    <>
      <ClientNavbar />

      {/* HERO SECTION */}
      <div className="container mt-5">
        <div
          className="p-5 text-center bg-light rounded-4 shadow"
          data-aos="fade-down"
        >
          <h1 className="fw-bold display-6">
            Welcome to <span className="text-primary">CarFix</span> 🚗
          </h1>
          <p className="lead mt-3">
            Professional car repair services — workshop or on-location
          </p>
        </div>
      </div>

      {/* FEATURES */}
      <div className="container mt-5">
        <div className="row g-4">

          <div className="col-md-4" data-aos="zoom-in">
            <div className="card h-100 shadow border-0 text-center">
              <div className="card-body">
                <div className="display-5 mb-3 text-primary">🔧</div>
                <h4 className="fw-bold">Book Workshop</h4>
                <p className="text-muted">
                  Choose a workshop and book an appointment easily
                </p>
                <a href="/client/book" className="btn btn-primary">
                  Book Now
                </a>
              </div>
            </div>
          </div>

          <div
            className="col-md-4"
            data-aos="zoom-in"
            data-aos-delay="200"
          >
            <div className="card h-100 shadow border-0 text-center">
              <div className="card-body">
                <div className="display-5 mb-3 text-success">🚚</div>
                <h4 className="fw-bold">Request On Location</h4>
                <p className="text-muted">
                  Repairman comes to your location with a driver
                </p>
                <a href="/client/request" className="btn btn-success">
                  Request Now
                </a>
              </div>
            </div>
          </div>

          <div
            className="col-md-4"
            data-aos="zoom-in"
            data-aos-delay="400"
          >
            <div className="card h-100 shadow border-0 text-center">
              <div className="display-5 mb-3 text-dark">📜</div>
              <h4 className="fw-bold">Car History</h4>
              <p className="text-muted">
                View all your past repairs and services
              </p>
              <a href="/client/history" className="btn btn-dark">
                View History
              </a>
            </div>
          </div>

        </div>
      </div>

      {/* INFO SECTION */}
      <div className="container mt-5 mb-5">
        <div
          className="row align-items-center p-4 bg-dark text-white rounded-4 shadow"
          data-aos="fade-up"
        >
          <div className="col-md-8">
            <h3 className="fw-bold">Why choose CarFix?</h3>
            <p className="mb-0">
              Fast service • Trusted workshops • Professional repairmen
            </p>
          </div>
          <div className="col-md-4 text-md-end mt-3 mt-md-0">
            <a href="/client/about" className="btn btn-outline-light">
              Learn More
            </a>
          </div>
        </div>
      </div>
    </>
  );
}

export default ClientHome;
