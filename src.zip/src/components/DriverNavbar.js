import React from "react";
import { handleLogout } from "../utils";

function DriverNavbar() {
    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
            <div className="container">
                <a className="navbar-brand fw-bold" href="/">Driver Repairman</a>

                <ul className="navbar-nav ms-auto">
                    <li className="nav-item">
                        <a className="nav-link" href="/driver-dashboard">Dashboard</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="/driver-history">History</a><li className="nav-item">
                            <a className="nav-link" href="/driver-requests">Requests</a>
                        </li>


                    </li>
                    <li className="nav-item">
                        <button className="btn btn-outline-light ms-2" onClick={handleLogout}>
                            Logout
                        </button>
                    </li>
                </ul>
            </div>
        </nav>
    );
}

export default DriverNavbar;
