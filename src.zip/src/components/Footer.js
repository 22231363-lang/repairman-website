import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";
import "../styles/Footer.css";  

function Footer() {
  // Initialize AOS
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  return (
    <footer className="bg-dark text-white pt-4 mt-5">
      <div className="container">
        <div className="row">

          {/* Quick Links */}
          <div className="col-md-4 mb-3" data-aos="fade-up">
            <h5 className="fw-bold">Quick Links</h5>
            <ul className="list-unstyled">
              <li><Link to="/" className="text-white text-decoration-none">Home</Link></li>
              <li><Link to="/services" className="text-white text-decoration-none">Services</Link></li>
              <li><Link to="/login" className="text-white text-decoration-none">Login</Link></li>
              <li><Link to="/register" className="text-white text-decoration-none">Register</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-md-4 mb-3" data-aos="fade-up" data-aos-delay="200">
            <h5 className="fw-bold">Contact Us</h5>
            <p className="mb-1">📧 Email: <a href="mailto:yourmail@gmail.com" className="text-white text-decoration-none">yourmail@gmail.com</a></p>
            <p>📞 Phone: <a href="tel:+96170000000" className="text-white text-decoration-none">+961 70 000 000</a></p>

            {/* Social Media Links */}
            <div className="mt-2">
              <a href="https://www.instagram.com" target="_blank" rel="noreferrer" className="text-white me-3 fs-5">
                <i className="bi bi-instagram"></i>
              </a>
              <a href="https://www.facebook.com" target="_blank" rel="noreferrer" className="text-white me-3 fs-5">
                <i className="bi bi-facebook"></i>
              </a>
              <a href="https://wa.me/96170000000" target="_blank" rel="noreferrer" className="text-white fs-5">
                <i className="bi bi-whatsapp"></i>
              </a>
            </div>
          </div>

          {/* Short Message */}
          <div className="col-md-4 mb-3" data-aos="fade-up" data-aos-delay="400">
            <h5 className="fw-bold">Why Choose Us?</h5>
            <p>
              Fast, trusted, and professional car repair assistance—anytime, anywhere.
              At <strong>RepairConnect</strong>, we bring the experts to you.
            </p>
          </div>

        </div>
      </div>

      <div className="bg-secondary text-center py-2 mt-3" data-aos="fade-up" data-aos-delay="600">
        <small>© 2025 RepairConnect. All Rights Reserved.</small>
      </div>
    </footer>
  );
}

export default Footer;
