import React from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/Navbar.css";  

function Navbar({ userType }) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm fixed-top">
      <div className="container">

        {/* Logo */}
        <Link className="navbar-brand fw-bold fs-3" to="/">
          RepairConnect
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">

            {/* Always visible */}
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link>
            </li>

            {/* Services page */}
            <li className="nav-item">
              <Link className="nav-link" to="/services">Services</Link>
            </li>

            {/* Dropdown Menu (empty for now but ready) */}
            <li className="nav-item dropdown">
              <a 
                className="nav-link dropdown-toggle" 
                href="#"
                id="servicesDropdown"
                role="button"
                data-bs-toggle="dropdown"
              >
                More
              </a>
              <ul className="dropdown-menu">
                <li><Link className="dropdown-item" to="/services#repair">Car Repair</Link></li>
                <li><Link className="dropdown-item" to="/services#towing">Towing</Link></li>
                <li><Link className="dropdown-item" to="/services#electrical">Electrical</Link></li>
              </ul>
            </li>

            {/* BEFORE LOGIN */}
            {!userType && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">Login</Link>
                </li>

                <li className="nav-item">
                  <Link className="nav-link" to="/register">Register</Link>
                </li>
              </>
            )}

            {/* AFTER LOGIN (based on user type) */}
            {userType === "client" && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/client/search">Search</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/client/chat">Chat</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-danger" to="/logout">Logout</Link>
                </li>
              </>
            )}

            {userType === "workshop" && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/workshop/dashboard">Dashboard</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/workshop/chat">Chat</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-danger" to="/logout">Logout</Link>
                </li>
              </>
            )}

            {userType === "driver" && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/driver/dashboard">Dashboard</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/driver/chat">Chat</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-danger" to="/logout">Logout</Link>
                </li>
              </>
            )}

            {userType === "admin" && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/admin/dashboard">Admin</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-danger" to="/logout">Logout</Link>
                </li>
              </>
            )}

          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
