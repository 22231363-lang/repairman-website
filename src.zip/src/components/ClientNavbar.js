import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import AOS from "aos";

function ClientNavbar() {
  const navigate = useNavigate();

  useEffect(() => {
    AOS.init({ duration: 800 });
  }, []);

  const logout = () => {
    localStorage.removeItem("client");
    navigate("/");
  };

  return (
    <nav
      className="navbar navbar-expand-lg navbar-dark bg-dark shadow"
      data-aos="fade-down"
    >
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/client/home">
          CarFix
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#clientNavbar"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="clientNavbar">
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0">

            <li className="nav-item">
              <Link className="nav-link" to="/client/book">
                Book
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/client/request">
                Request On Location
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/client/history">
                Car History
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/client/about">
                About
              </Link>
            </li>

            <li className="nav-item">
              <button className="btn btn-outline-danger ms-3" onClick={logout}>
                Logout
              </button>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  );
}

export default ClientNavbar;
