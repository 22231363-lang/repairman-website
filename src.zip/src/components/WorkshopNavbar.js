import React from "react";
import { handleLogout } from "../utils";

function WorkshopNavbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
      <div className="container">
        <a className="navbar-brand fw-bold" href="/">Workshop</a>
        <ul className="navbar-nav ms-auto">
          <li className="nav-item">
            <a className="nav-link" href="/workshop-schedule">Schedule</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="/workshop-reports">Reports</a>
          </li>
          <li className="nav-item">
            <button className="btn btn-outline-light ms-2" onClick={handleLogout}>
              Logout
            </button>
          </li>
        </ul>
      </div>
    </nav>
  );
}

export default WorkshopNavbar;
