// src/utils.js

/* LOGOUT WITH CONFIRMATION */
export const handleLogout = () => {
  const confirmed = window.confirm("Are you sure you want to logout?");
  if (confirmed) {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = "/";
  }
};

/* SAVE REPORT FROM WORKSHOP */
export const saveReport = (carId, report) => {
  const reports = JSON.parse(localStorage.getItem("carReports")) || {};
  if (!reports[carId]) reports[carId] = [];
  reports[carId].push(report);
  localStorage.setItem("carReports", JSON.stringify(reports));
};

/* GET REPORTS FOR CLIENT */
export const getReports = (carId) => {
  const reports = JSON.parse(localStorage.getItem("carReports")) || {};
  return reports[carId] || [];
};
