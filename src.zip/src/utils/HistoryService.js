// src/utils/historyService.js

export const saveHistory = (record) => {
  const history = JSON.parse(localStorage.getItem("serviceHistory")) || [];
  history.push(record);
  localStorage.setItem("serviceHistory", JSON.stringify(history));
};

export const getHistory = () => {
  return JSON.parse(localStorage.getItem("serviceHistory")) || [];
};
